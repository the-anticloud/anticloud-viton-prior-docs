# 25 Millennium Problem Proposals

**Project:** VITON
**Upstream:** https://github.com/xthan/VITON

Content specific to VITON in category CLOTHING_RETAIL.
